package com.example.equipojugadores.View;

public class EquipoAdapter {
}
