package com.example.equipojugadores;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.AbsListView;
import android.widget.Button;

import com.example.equipojugadores.View.EquipoAdapter;
import com.example.equipojugadores.View.MainViewModel;

public class MainActivity extends AppCompatActivity {




    private RecyclerView myRecycler;
    private RecyclerView.LayoutManager layoutManager;
    private MainViewModel viewModel;
    private EquipoAdapter equipoAdapter;

    private Button btAñadirEquipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
    }

    private void initComponents() {

        myRecycler = findViewById(R.id.rvEquipos);
        btAñadirEquipo = findViewById(R.id.btAñadirEquipo);
    }
}
